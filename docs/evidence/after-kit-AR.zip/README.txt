Initials “AR” in Fraunces, #111111 letters with no background shape brand kit, made with Lettermint.

Files
  logo.svg               vector mark
  favicon.ico            16, 32 and 48 px
  favicon-16/32.png      browser tab icons
  apple-touch-icon.png   180 px, iOS home screen
  icon-192/512.png       PWA and Android icons
  avatar-400.png         social profile picture
  og-image.png           1200x630 link preview
  site.webmanifest       PWA manifest
  palette.css            brand colours as CSS variables
  tailwind.config.js     the same colours for Tailwind

Paste into <head>
  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="icon" href="/logo.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">
  <meta property="og:image" content="https://YOUR-SITE/og-image.png">
