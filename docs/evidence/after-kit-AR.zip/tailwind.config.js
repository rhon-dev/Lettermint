/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#111111',
          50: '#f7f7f7',
          100: '#cbcbcb',
          200: '#a5a5a5',
          300: '#848484',
          400: '#656565',
          500: '#4a4a4a',
          600: '#414141',
          700: '#393939',
          800: '#2f2f2f',
          900: '#252525',
          950: '#191919',
          on: '#ffffff',
          complement: '#111111',
        },
      },
    },
  },
};
